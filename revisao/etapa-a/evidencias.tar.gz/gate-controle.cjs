const fs=require('fs'),path=require('path'),crypto=require('crypto'),zlib=require('zlib');
const {repo,out}=require('./controle.cjs'),{PNG}=require('C:/Users/breno/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/pngjs');
const dir=path.join(out,'gate-controle');fs.mkdirSync(dir,{recursive:true});
const baseline=path.join(repo,'revisao/lote-2.1/antes');const read=(id,suffix)=>JSON.parse(zlib.gunzipSync(fs.readFileSync(path.join(baseline,id+suffix+'.json.gz'))));
const allowedNew=new Set(JSON.parse(fs.readFileSync(path.join(repo,'revisao/lote-2.1/tokens-propostos.json'))).map(t=>t.name)); // lista anterior INALTERADA; nenhum destes nomes existe no controle
const originalGate=fs.readFileSync(path.join(repo,'revisao/lote-2.1/gate.cjs'),'utf8');
const snippet=originalGate.slice(originalGate.indexOf('async function snapshot('),originalGate.indexOf('\nfunction mismatch('));
const snapshot=new Function('allowedNew',snippet+';return snapshot;')(allowedNew);
const expectedManifest=JSON.parse(fs.readFileSync(path.join(baseline,'resultado.json')));
const existingCustom=new Set();for(const v of expectedManifest.normal){const n=read(v.id,'-normal');for(const row of n.rows)for(const p of Object.keys(row.style))if(p.startsWith('--'))existingCustom.add(p);for(const s of read(v.id,'-estados'))for(const d of s.delta)for(const p of Object.keys(d.properties||d.style||{}))if(p.startsWith('--'))existingCustom.add(p);}
const result={head:'6c4e314',origin:'http://127.0.0.1:5190',reference:'revisao/lote-2.1/antes/resultado.json',phase0:'revisao/baseline/',screens:[],states:[],errors:[],fullDifferences:true,existingCustom:[...existingCustom].sort()};
const zero=()=>({a:0,b:0,c:0,structure:0});
function pixels(a,b){a=PNG.sync.read(a);b=PNG.sync.read(b);if(a.width!==b.width||a.height!==b.height)return -1;let count=0;for(let i=0;i<a.data.length;i+=4)if(a.data[i]!==b.data[i]||a.data[i+1]!==b.data[i+1]||a.data[i+2]!==b.data[i+2]||a.data[i+3]!==b.data[i+3])count++;return count;}
const map=n=>new Map(n.rows.map(r=>[r.key,r.style]));
function expand(base,delta){const m=new Map(base);for(const d of delta){if(d.missing)m.delete(d.key);else if(d.style)m.set(d.key,d.style);else {const style={...(m.get(d.key)||{})};for(const [p,v]of Object.entries(d.properties||{})){if(v===null)delete style[p];else style[p]=v}m.set(d.key,style)}}return m;}
function compare(a,b){const counts=zero(),properties=new Map();for(const key of new Set([...a.keys(),...b.keys()])){const old=a.get(key),now=b.get(key);if(!old||!now)counts.structure++;for(const p of new Set([...Object.keys(old||{}),...Object.keys(now||{})])){const x=old?.[p],y=now?.[p];if(x===y)continue;const group=!p.startsWith('--')?'a':existingCustom.has(p)?'b':'c';counts[group]++;const pk=JSON.stringify([group,p,x??null,y??null]);if(!properties.has(pk))properties.set(pk,{group,property:p,before:x??null,after:y??null,count:0,witnesses:[]});const row=properties.get(pk);row.count++;if(row.witnesses.length<3)row.witnesses.push(key)}}return{counts,properties:[...properties.values()]};}
const save=()=>fs.writeFileSync(path.join(dir,'resultado.json'),JSON.stringify(result,null,2));
const gate={capture:async(page,theme,name)=>{
 const id=theme+'-'+name,png=await page.screenshot({animations:'disabled',caret:'hide'});fs.writeFileSync(path.join(dir,id+'.png'),png);
 const normal=await snapshot(page),old=read(id,'-normal'),a=map(old),b=map(normal),normalDiff=compare(a,b);
 const row={id,theme,name,elements:normal.rows.length,controls:normal.controls.length,pixelsPhase0:pixels(png,fs.readFileSync(path.join(repo,'revisao/baseline',id+'.png'))),pixelsAntes:pixels(png,fs.readFileSync(path.join(baseline,id+'.png'))),normal:normalDiff,stateTotals:zero(),stateCount:0};result.screens.push(row);save();
 fs.writeFileSync(path.join(dir,id+'-normal.json.gz'),zlib.gzipSync(JSON.stringify(normal)));
 const expectedStates=read(id,'-estados'),lookup=new Map(expectedStates.map(s=>[s.target.key+'|'+s.state,s])),states=[];
 const controls=new Map([...old.controls,...normal.controls].map(t=>[t.key,t]));const cdp=await page.context().newCDPSession(page);await cdp.send('DOM.enable');await cdp.send('CSS.enable');const doc=await cdp.send('DOM.getDocument');
 try{for(const target of controls.values()){const {nodeId}=await cdp.send('DOM.querySelector',{nodeId:doc.root.nodeId,selector:target.key});if(!nodeId){result.errors.push({id,target:target.key,error:'controle ausente'});continue}
 for(const [state,forcedPseudoClasses]of Object.entries({hover:['hover'],active:['active'],'focus-visible':['focus','focus-visible'],disabled:['disabled']})){
  await cdp.send('CSS.forcePseudoState',{nodeId,forcedPseudoClasses});try{const matched=await page.locator(target.key).evaluate((e,s)=>e.matches(':'+s),state),delta=await snapshot(page,true),expected=lookup.get(target.key+'|'+state);if(!expected){result.errors.push({id,target:target.key,state,error:'estado sem referência'});continue}
  const diff=compare(expand(a,expected.delta),expand(b,delta));const log={id,theme,screen:name,target:target.key,category:target.category,state,matched,...diff};result.states.push(log);states.push({target,state,delta});row.stateCount++;for(const k of ['a','b','c','structure'])row.stateTotals[k]+=diff.counts[k];if(!matched)result.errors.push({id,target:target.key,state,error:'pseudoestado não aplicado'});
  }finally{await cdp.send('CSS.forcePseudoState',{nodeId,forcedPseudoClasses:[]})}
 }
 }}finally{await cdp.detach()}
 fs.writeFileSync(path.join(dir,id+'-estados.json.gz'),zlib.gzipSync(JSON.stringify(states)));save();console.log(JSON.stringify({id,pixelsPhase0:row.pixelsPhase0,pixelsAntes:row.pixelsAntes,normal:row.normal.counts,states:row.stateCount,stateTotals:row.stateTotals}));
}};
let source=fs.readFileSync(path.join(repo,'revisao/baseline/capturar.cjs'),'utf8');source=source.replace("const dir=__dirname, origin='http://127.0.0.1:5180'","const dir=path.join(__dirname,'gate-controle'), origin='http://127.0.0.1:5190'");
const start=source.indexOf(' const shot=async(name)=>'),end=source.indexOf('\n const step=',start);source=source.slice(0,start)+" const shot=async(name)=>{await page.waitForTimeout(150);await gate.capture(page,theme,name);manifest.screens.push({theme,name})};"+source.slice(end);
source=source.replace("(async()=>{const browser=","return (async()=>{const browser=");
new Function('require','__dirname','gate',source)(require,out,gate).then(()=>{result.complete=result.screens.length===72&&result.states.length===expectedManifest.states.length;save();console.log(JSON.stringify({complete:result.complete,screens:result.screens.length,states:result.states.length,errors:result.errors.length}))}).catch(e=>{result.errors.push({fatal:e.stack});save();console.error(e);process.exitCode=1});
