const fs=require('fs'),path=require('path');const {out,repo}=require('./controle.cjs');const read=f=>JSON.parse(fs.readFileSync(path.join(out,f)));
const control=read('controle-comparacao.json'),gate=read('gate-controle/resultado.json'),replay=read('gate-fase0-reconstruido/resultado.json'),cross=read('comparacao-head-vs-fase0-reconstruida.json'),bisect=read('bisseccao.json'),proof=read('prova-final.json'),sources=read('head-fontes.json'),origins=read('origens-completas.json'),deps=read('dependencias.json'),integrity=read('integridade.json'),grep=read('grep-bordas.json');
if(!gate.complete||!replay.complete||!cross.complete)throw new Error('Percursos incompletos');
const esc=s=>String(s??'').replaceAll('|','\\|').replaceAll('\n',' '),table=(h,rows)=>'\n| '+h.join(' | ')+' |\n| '+h.map(()=>'---').join(' | ')+' |\n'+rows.map(r=>'| '+r.map(esc).join(' | ')+' |').join('\n')+'\n';
const sums=(rows,key)=>rows.reduce((a,r)=>{const n=key==='normal'?r.normal.counts:r[key];for(const k of ['a','b','c','structure'])a[k]+=n[k];return a},{a:0,b:0,c:0,structure:0});
const totals=[];for(const theme of ['escuro','claro']){const rows=gate.screens.filter(r=>r.theme===theme);totals.push({theme,normal:sums(rows,'normal'),states:sums(rows,'stateTotals'),screens:rows.length,stateCases:rows.reduce((a,b)=>a+b.stateCount,0)})}
const uniqueProps=new Map();for(const row of gate.screens)for(const p of row.normal.properties){const key=p.group+'|'+p.property+'|'+p.before+'|'+p.after;if(!uniqueProps.has(key))uniqueProps.set(key,{...p,count:0});uniqueProps.get(key).count+=p.count;}
const emitted=read('controle-1/css.json')[0],f0=read('espelho-fase0-build/css.json')[0],f0match=read('fase0-sem-capturar-build/css.json')[0],withoutSix=read('sem-seis-origens-build/css.json')[0],withoutEight=read('sem-todas-origens-build/css.json')[0];
let md=`# Etapa A — diagnóstico da geração de CSS

Data: 25/10/2026. Controle: **HEAD 6c4e3144c4965e9ed2ab28d32af06bfa0704866d**. **Lote 2.1 não reaplicado. Nenhuma alteração em src/, pipeline, allowlist ou baseline. Nenhuma correção implementada.**

## Conclusão

**Causa de emissão provada:** a descoberta automática do Tailwind inclui arquivos de auditoria/evidência em \`revisao/\`. Palavras de propriedades CSS e nomes de variáveis nesses arquivos viram candidatos do compilador, mesmo sem serem classes do aplicativo. Oito arquivos contribuem diretamente para as três variáveis investigadas. Retirá-los apenas de um espelho temporário elimina as três; recolocar cada arquivo isoladamente reproduz sua contribuição.

Os dois builds limpos do HEAD produziram **201.067 bytes idênticos byte a byte**, verificados por \`Buffer.equals\` e SHA-256. As extras já existem nesse controle, sem qualquer token ou consumidor do lote. Portanto a etapa condicional 4 (reaplicar a tentativa em camadas) **não foi executada**.

O gate diagnóstico percorreu **72 telas e 4.936 estados**, sem interromper em divergências: pixels iguais às imagens da Fase 0 e de antes/; **zero diferenças em propriedades CSS normais e valores de custom properties já existentes**. Há somente adições de três nomes com valor computado. Isso descreve o controle; não aprova o Lote 2.1.

## 1. Controle e determinismo

Comando lógico: \`npm run build\` (o harness externo invoca o npm-cli instalado, sem mudar o script do package.json). Execuções sequenciais em processos novos, sem criar novos arquivos na árvore do projeto entre elas. Logs e dados foram gravados fora da raiz varrida, para evitar retroalimentar o compilador. Uma falha inicial de sintaxe da invocação do shell ocorreu antes de npm executar e foi corrigida apenas no harness externo; não conta como um build de controle válido.

`;
md+=table(['Execução','CSS','Bytes','SHA-256'],control.build1.map(r=>['controle 1',r.file,r.bytes,r.sha256]).concat(control.build2.map(r=>['controle 2',r.file,r.bytes,r.sha256])));
md+=`\n**Buffer.equals = ${control.directBufferEquality}; comparação SHA-256 = ${control.byteIdentical}.** Não foi usada tolerância, normalização de CSS ou permissão nova para aceitar as variáveis.

O controle visual usou um servidor Vite novo em 127.0.0.1:5190, evitando depender do processo antigo aquecido. Mesma configuração de projeto; apenas porta CLI diferente. Perfis descartáveis, 390×844, Edge 156.0.4314.42, pt-BR, America/Sao_Paulo, data congelada como no baseline, redução de movimento e requisições externas bloqueadas.

## 2. Diferenças dos grupos (a), (b) e (c)

- **(a)** propriedade CSS normal: valor ou presença diferente.
- **(b)** custom property observada na referência anterior: valor/presença diferente, inclusive remoção.
- **(c)** nome de custom property não observado na referência anterior, adicionado com valor.
- Cada ocorrência é um par **elemento/pseudo-elemento × propriedade × observação**. Valores repetidos em vários elementos/estados contam várias vezes; não são milhões de nomes distintos. Foram encontrados apenas **3 nomes distintos no grupo (c)**.
- Normais e estados são contados separadamente. O gate mantém snapshots completos comprimidos e deltas por estado, permitindo reconstrução de todas as propriedades. Testa um controle por vez, via CDP, e confere que o pseudoestado realmente corresponde. Nenhuma diferença de layout/estrutura foi detectada.

`;
md+=table(['Tema','Telas','Casos de estado','Normal (a)','Normal (b)','Normal (c)','Estados (a)','Estados (b)','Estados (c)'],totals.map(t=>[t.theme,t.screens,t.stateCases,t.normal.a,t.normal.b,t.normal.c,t.states.a,t.states.b,t.states.c]));
md+=table(['Grupo','Propriedade','Antes','Controle','Ocorrências nas observações normais','Origem demonstrada'],[...uniqueProps.values()].map(p=>[p.group,p.property,p.before??'(ausente)',p.after,p.count,p.property==='--tw-outline-style'?'candidato outline → utilitário e registro @property':'candidatos ease-* ou --ease-* → variável de tema marcada como usada']));
md+=`\n### Todas as telas, por tema

Pixels nas colunas P0/antes são diferenças de pixels RGBA, não apenas hash de PNG. As duas colunas são zero em todas as 72 telas.
`;
md+=table(['Tema','Tela','Pixels P0','Pixels antes','Normal a','Normal b','Normal c','Casos de estado','Estados a','Estados b','Estados c'],gate.screens.map(r=>[r.theme,r.name,r.pixelsPhase0,r.pixelsAntes,r.normal.counts.a,r.normal.counts.b,r.normal.counts.c,r.stateCount,r.stateTotals.a,r.stateTotals.b,r.stateTotals.c]));
md+=`\n### Referência da Fase 0: limite histórico e reconstrução

A Fase 0 guardou 72 PNG e uma seleção de estilos, mas **não** uma matriz completa de propriedades/estados forçados. A matriz completa existente é a de \`revisao/lote-2.1/antes/\`. Não inventei uma matriz histórica nem substituí nenhum arquivo de baseline.

Para complementar a comparação, reconstruí o snapshot Git f732e69 num diretório temporário, com as dependências atuais idênticas às do controle. Omitir **somente** \`revisao/baseline/capturar.cjs\` desse espelho reproduziu \`${f0match.file}\`, **${f0match.bytes} bytes**, os mesmos nome/tamanho registrados em \`baseline/validacao.json\`. Esse script foi criado depois do build original; a palavra \`static\` em \`static now()\` acrescenta o utilitário de 24 bytes quando passa a integrar a descoberta automática. Com o script presente, o snapshot compilou ${f0.bytes} bytes. Nenhum arquivo foi omitido da cópia real.

Não há bytes/hash histórico do bundle completo versionado para comparação literal com 2026-10-25; nome/tamanho são os metadados históricos disponíveis. A reconstrução está identificada como tal, não como observação recuperada do passado.

Essa reconstrução recebeu outro percurso completo, servidor novo em 127.0.0.1:5200: **72 PNG iguais aos originais e aos de antes/, 4.936 estados; todos os grupos a/b/c zerados contra antes/**. A comparação direta posterior entre os snapshots completos do HEAD e os reconstruídos repetiu as mesmas adições do grupo (c). Dados: [comparacao-head-vs-fase0-reconstruida.json](comparacao-head-vs-fase0-reconstruida.json).

## 3. Bissecção — arquivos de revisão, lote e histórico

Cada braço foi extraído de um arquivo Git para uma pasta temporária nova. Nenhum src/ foi editado, nem mesmo nos espelhos. Exclusões foram de arquivos de evidências; dependências compartilhadas por junction, sem reinstalação. O espelho completo do HEAD produziu exatamente o mesmo SHA-256 do projeto real, validando o método. Os hashes agregados de src/ dos quatro braços principais são iguais.

`;
const arms=bisect.map(a=>[a.name,a.purpose,a.css[0].bytes,a.css[0].names.length,a.css[0].watched.join(', ')||'(nenhuma)',a.css[0].sha256]);arms.push(['sem seis origens de classes','Retirada parcial; ainda ficam referências --ease-* em relatórios',withoutSix.bytes,withoutSix.names.length,'--ease-in-out, --ease-out',withoutSix.sha256],['sem oito origens','Retirada completa dos oito arquivos causadores, só no espelho',withoutEight.bytes,withoutEight.names.length,'(nenhuma)',withoutEight.sha256]);md+=table(['Braço','Isolamento','Bytes CSS','Nomes emitidos','Três variáveis investigadas','SHA-256'],arms);
md+=`\n**Leituras:**

1. Grupo (i): tirar toda revisao/ elimina as três, mas também reduz nomes emitidos de 61 da Fase 0 para 42. Portanto ignorar/mover indiscriminadamente toda a pasta pode remover estilos/variáveis que já faziam parte do baseline; não é a proposta mínima.
2. Grupo (ii): tirar apenas revisao/lote-2.1/ não resolve. Os arquivos da Fase 1 já bastam para emitir as extras.
3. Grupo (iii): src/, package.json, package-lock.json e vite.config.ts não mudaram entre Fase 0 e HEAD. Voltar ao snapshot de evidências da Fase 0 elimina as extras, usando a mesma instalação atual de pacotes. Isso isola a contribuição dos artefatos, sem atribuir a causa a uma versão presumida.
4. Tirar as oito origens restaura exatamente o **conjunto de 61 nomes emitidos da Fase 0**, sem nome a mais ou a menos. Não se afirma que o CSS inteiro fica idêntico: sobram utilitários de outros artefatos, e nenhum movimento foi aplicado no projeto.

### Prova individual de causalidade

Partindo do espelho sem as oito origens, cada arquivo foi recolocado sozinho; extração e compilação do mesmo Tailwind reproduziram a coluna abaixo. Além disso, cada candidato foi compilado sozinho, sem código do app. Não se depende só de encontrar palavras com grep.
`;
md+=table(['Arquivo recolocado isoladamente','Candidatos relevantes','Variáveis reproduzidas'],proof.individualAdditions.map(a=>[a.file,a.allTriggerCandidates.join(', '),a.emitted.join(', ')||'(nenhuma)']));
md+=table(['Candidato mínimo','Variável emitida'],proof.minimal.map(m=>[m.candidate,m.emitted.join(', ')]));
md+=`\nO fluxo local está em \`node_modules/@tailwindcss/vite/dist/index.mjs:1\`: scanner com base no config.root e padrão **/*, seguido de compiler.build(candidates). Em \`node_modules/tailwindcss/dist/lib.js:38\`, entradas que começam por dois hífens passam por theme.markUsedVariable. Assim, uma chave JSON ou menção Markdown como \`--ease-out\` também faz o tema emitir a variável; não precisa haver classe ease-out no JSX.

\`outline\` cria suporte ao utilitário e a propriedade registrada \`--tw-outline-style\`, com valor inicial solid. As demais são definidas em \`node_modules/tailwindcss/theme.css:435–436\`. Os arquivos de prova mínima estão no pacote de evidências.

O CSS do HEAD contém 13 nomes emitidos a mais que a reconstrução da Fase 0. Nas telas/estados computados, somente três têm valor novo observável; os demais são suporte de easing/backdrop sem valor computado adicional nessas observações. Lista de todos os 13:

`;
md+='```text\n'+emitted.names.filter(n=>!f0.names.includes(n)).join('\n')+'\n```\n';
md+=`\n### Dependências e hashes

Foram conferidos **512 pacotes instalados**, sem divergência de versão em relação ao lockfile atual. package.json, package-lock.json e vite.config.ts têm os mesmos bytes Git em Fase 0 e HEAD. A diferença entre o hash Git/LF e o hash físico/CRLF do lockfile é apenas representação de fim de linha; o hash físico é igual no projeto e nos espelhos.
`;
md+=table(['Arquivo','SHA-256 Git Fase 0','SHA-256 Git HEAD','Iguais'],deps.history.map(h=>[h.file,h.phase0,h.head,h.sameGitBytes]));
md+=table(['Pacote crítico','Versão instalada','SHA-256 agregado de fontes/binding atuais'],deps.packageSourceHashes.filter(p=>!p.absent).map(p=>[p.name,p.version,p.sha256]));
md+=`\nHashes completos por arquivo estão em dependencias.json. Caches .vite/.tmp e node_modules aninhados não integram o hash agregado de cada pacote crítico. O executável Node atual é ${deps.node.version}, SHA-256 ${deps.node.sha256}. A Fase 0 **não registrou hashes históricos de node_modules nem do Node**; não é possível certificar retrospectivamente esses bytes. Não houve npm install/update nesta etapa e todos os braços usaram a mesma instalação, eliminando essa variável dos testes causais.

### O que está provado e o que continua hipótese

**Provado:** oito artefatos fora de src/ são fontes efetivas de candidatos que emitem as três variáveis; retirar/recolocar e reproduções mínimas confirmaram o encadeamento. O HEAD frio já as emite sem o Lote 2.1. A tentativa não era necessária para produzi-las.

**Não reconstituído historicamente:** o evento exato de HMR/cache que fez a referência antes/ ficar sem elas e a recompilação posterior incluí-las. O plugin mantém candidatos em memória; um processo aquecido/recompilação tardia é compatível com os dados, mas não há logs históricos que provem esse momento. Essa limitação não invalida a prova controlada de quais entradas geram a emissão.

## 4. Fontes automáticas e palavras encontradas

O scanner nativo instalado listou **${sources.fileCount} arquivos**, sendo **${sources.outsideSrc.length} fora de src/**. Base automática: raiz do projeto, padrão **/*; compiler.root=null e sem fontes adicionais declaradas no CSS. Inventário completo: [head-fontes.json](head-fontes.json).

Apenas achar texto ou chamar getCandidatesWithPositions em CSS não prova contribuição automática. Há folhas CSS listadas com as palavras que não geram esses candidatos no scan automático; isso foi separado de fontes efetivas. As oito efetivas são todas artefatos de revisão, não componentes.

`;
md+=table(['Fonte efetiva','Candidatos automáticos','Linhas de exemplo (todas em origens-completas.json)'],origins.map(f=>[f.file,f.candidates.join(', '),[...new Set((f.locations.length?f.locations:f.literalLocations||[]).map(l=>l.line))].slice(0,12).join(', ')]));
md+='\n### Arquivos fora de src/ que contêm as palavras pesquisadas\n\nAs contagens são literais; incluem prefixos de variáveis, trechos de CSS e menções em documentação. A coluna de candidatos é a contribuição efetiva confirmada, não uma inferência por substring.\n';
md+=table(['Arquivo','ease-in-out','ease-out','outline','Candidatos efetivos relevantes'],sources.findings.filter(f=>f.outsideSrc).map(f=>[f.file,...['ease-in-out','ease-out','outline'].map(t=>f.words.filter(w=>w.term===t).length),(f.effectiveCandidates||[]).join(', ')||'(nenhum destes)']));
md+='\n### Lista completa das fontes automáticas fora de src/\n\n```text\n'+[...sources.outsideSrc].sort().join('\n')+'\n```\n';
md+=`\n## 5. Correção mínima proposta — NÃO APLICADA

**Preferida: retirar da árvore varrida os oito arquivos efetivos listados acima**, mantendo a estrutura relativa num diretório irmão, por exemplo \`vida-em-dia-evidencias/revisao/\`. Ajustar apenas os caminhos das ferramentas para ler/gravar nesse diretório externo; futuras evidências também devem nascer fora da raiz. Se necessário, deixar no endereço antigo um ponteiro simples sem dados CSS, cujo conjunto de candidatos deve ser conferido.

Mover é tecnicamente possível e foi simulado nos espelhos. Nenhum dos oito arquivos é lógica, teste ou componente do app. **Nenhum causador original foi movido/excluído na cópia real.** O relatório desta etapa também foi produzido fora da árvore para não se tornar outra entrada do compilador.

A proposta é pontual: não mover/ignorar indiscriminadamente toda revisao/, pois isso altera o conjunto antigo de estilos/variáveis. Depois de eventual autorização, repetir o gate antes de aceitar qualquer migração. A simulação demonstra a remoção das três e a igualdade de nomes emitidos, não substitui essa validação pós-correção na cópia.

**Fallback não escolhido:** somente se uma restrição impedir mover e houver autorização específica, declarar exclusões precisas em \`src/index.css\`, após a linha 1 (a partir da linha 2), usando @source not para os oito caminhos. Não excluir a pasta inteira. Nenhuma diretiva, configuração, allowlist, versão, pipeline ou baseline foi alterado nesta etapa.

## 6. #7c8d76 por grep

Escopo: sete CSS de src/, os mesmos do Apêndice D. Não inclui dist/, propostas descartadas ou palavras em comentários dos relatórios. Comando executado:

`;
md+='```powershell\n'+grep.command+'\n```\n\nSaída literal:\n\n```text\n'+grep.stdout.trimEnd()+'\n```\n';
md+=table(['Arquivo','Ocorrências'],Object.entries(grep.counts));md+=`\n**Total: ${grep.total}.** Arquivos sem saída do rg têm zero. Nenhuma substituição de borda foi realizada.

## 7. Integridade e estado final

Os hashes dos **169 arquivos de src/ da cópia e 153 do original** permanecem iguais à Fase 0, incluindo renderizadores e testes. Os quatro espelhos principais têm o mesmo hash agregado de src/. O HEAD da execução foi mantido sem alterações de arquivos enquanto se coletavam os controles; resultados, scripts e variantes ficaram em diretório temporário externo. As únicas escritas do build no projeto foram artefatos ignorados/cache padrão das ferramentas.

Nenhum comando de aplicação do Lote 2.1 foi executado. Nenhuma regra/token do app foi alterado; nenhuma correção proposta foi aplicada. Não houve push ou deploy. **Etapa A concluída; parar e aguardar decisão.**
`;
fs.writeFileSync(path.join(out,'RELATORIO-ETAPA-A.md'),md);
fs.writeFileSync(path.join(out,'resumo-etapa-a.json'),JSON.stringify({head:control.head,buildsByteIdentical:control.directBufferEquality,screens:gate.screens.length,states:gate.states.length,pixelsAllZero:gate.screens.every(s=>s.pixelsPhase0===0&&s.pixelsAntes===0),totals,normalUniqueAdded:[...uniqueProps.values()].map(({witnesses,...v})=>v),originFiles:origins.map(f=>f.file),correctionApplied:false,phase0ReplayComplete:replay.complete,sourcePreserved:integrity.sourcePreserved,grepTotal:grep.total},null,2));console.log(JSON.stringify({report:path.join(out,'RELATORIO-ETAPA-A.md'),totals,origins:origins.length,sourcePreserved:integrity.sourcePreserved}));
