# Etapa A — diagnóstico da geração de CSS

Data: 25/10/2026. Controle: **HEAD 6c4e3144c4965e9ed2ab28d32af06bfa0704866d**. **Lote 2.1 não reaplicado. Nenhuma alteração em src/, pipeline, allowlist ou baseline. Nenhuma correção implementada.**

## Conclusão

**Causa de emissão provada:** a descoberta automática do Tailwind inclui arquivos de auditoria/evidência em `revisao/`. Palavras de propriedades CSS e nomes de variáveis nesses arquivos viram candidatos do compilador, mesmo sem serem classes do aplicativo. Oito arquivos contribuem diretamente para as três variáveis investigadas. Retirá-los apenas de um espelho temporário elimina as três; recolocar cada arquivo isoladamente reproduz sua contribuição.

Os dois builds limpos do HEAD produziram **201.067 bytes idênticos byte a byte**, verificados por `Buffer.equals` e SHA-256. As extras já existem nesse controle, sem qualquer token ou consumidor do lote. Portanto a etapa condicional 4 (reaplicar a tentativa em camadas) **não foi executada**.

O gate diagnóstico percorreu **72 telas e 4.936 estados**, sem interromper em divergências: pixels iguais às imagens da Fase 0 e de antes/; **zero diferenças em propriedades CSS normais e valores de custom properties já existentes**. Há somente adições de três nomes com valor computado. Isso descreve o controle; não aprova o Lote 2.1.

## 1. Controle e determinismo

Comando lógico: `npm run build` (o harness externo invoca o npm-cli instalado, sem mudar o script do package.json). Execuções sequenciais em processos novos, sem criar novos arquivos na árvore do projeto entre elas. Logs e dados foram gravados fora da raiz varrida, para evitar retroalimentar o compilador. Uma falha inicial de sintaxe da invocação do shell ocorreu antes de npm executar e foi corrigida apenas no harness externo; não conta como um build de controle válido.


| Execução | CSS | Bytes | SHA-256 |
| --- | --- | --- | --- |
| controle 1 | index-CoJvi76B.css | 201067 | a2e67cec7c532920e6a02be9a188a6440cc0a631f2ee7d37b876210687d738e3 |
| controle 2 | index-CoJvi76B.css | 201067 | a2e67cec7c532920e6a02be9a188a6440cc0a631f2ee7d37b876210687d738e3 |

**Buffer.equals = true; comparação SHA-256 = true.** Não foi usada tolerância, normalização de CSS ou permissão nova para aceitar as variáveis.

O controle visual usou um servidor Vite novo em 127.0.0.1:5190, evitando depender do processo antigo aquecido. Mesma configuração de projeto; apenas porta CLI diferente. Perfis descartáveis, 390×844, Edge 156.0.4314.42, pt-BR, America/Sao_Paulo, data congelada como no baseline, redução de movimento e requisições externas bloqueadas.

## 2. Diferenças dos grupos (a), (b) e (c)

- **(a)** propriedade CSS normal: valor ou presença diferente.
- **(b)** custom property observada na referência anterior: valor/presença diferente, inclusive remoção.
- **(c)** nome de custom property não observado na referência anterior, adicionado com valor.
- Cada ocorrência é um par **elemento/pseudo-elemento × propriedade × observação**. Valores repetidos em vários elementos/estados contam várias vezes; não são milhões de nomes distintos. Foram encontrados apenas **3 nomes distintos no grupo (c)**.
- Normais e estados são contados separadamente. O gate mantém snapshots completos comprimidos e deltas por estado, permitindo reconstrução de todas as propriedades. Testa um controle por vez, via CDP, e confere que o pseudoestado realmente corresponde. Nenhuma diferença de layout/estrutura foi detectada.


| Tema | Telas | Casos de estado | Normal (a) | Normal (b) | Normal (c) | Estados (a) | Estados (b) | Estados (c) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| escuro | 36 | 2476 | 0 | 0 | 12864 | 0 | 0 | 980313 |
| claro | 36 | 2460 | 0 | 0 | 12342 | 0 | 0 | 938340 |

| Grupo | Propriedade | Antes | Controle | Ocorrências nas observações normais | Origem demonstrada |
| --- | --- | --- | --- | --- | --- |
| c | --ease-in-out | (ausente) | cubic-bezier(0.4, 0, 0.2, 1) | 8402 | candidatos ease-* ou --ease-* → variável de tema marcada como usada |
| c | --ease-out | (ausente) | cubic-bezier(0, 0, 0.2, 1) | 8402 | candidatos ease-* ou --ease-* → variável de tema marcada como usada |
| c | --tw-outline-style | (ausente) | solid | 8402 | candidato outline → utilitário e registro @property |

### Todas as telas, por tema

Pixels nas colunas P0/antes são diferenças de pixels RGBA, não apenas hash de PNG. As duas colunas são zero em todas as 72 telas.

| Tema | Tela | Pixels P0 | Pixels antes | Normal a | Normal b | Normal c | Casos de estado | Estados a | Estados b | Estados c |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| escuro | hoje | 0 | 0 | 0 | 0 | 270 | 36 | 0 | 0 | 9720 |
| escuro | comida | 0 | 0 | 0 | 0 | 219 | 28 | 0 | 0 | 6132 |
| escuro | medidas-vazia | 0 | 0 | 0 | 0 | 195 | 28 | 0 | 0 | 6300 |
| escuro | registrar-medidas | 0 | 0 | 0 | 0 | 381 | 76 | 0 | 0 | 28956 |
| escuro | medida-peso-rolar | 0 | 0 | 0 | 0 | 528 | 148 | 0 | 0 | 78144 |
| escuro | medida-peso-digitar | 0 | 0 | 0 | 0 | 444 | 100 | 0 | 0 | 44400 |
| escuro | seletor-data | 0 | 0 | 0 | 0 | 504 | 140 | 0 | 0 | 70560 |
| escuro | evolucao-vazia | 0 | 0 | 0 | 0 | 195 | 28 | 0 | 0 | 6384 |
| escuro | treino-fichas-vazia | 0 | 0 | 0 | 0 | 246 | 48 | 0 | 0 | 11808 |
| escuro | nova-ficha-sem-selecao | 0 | 0 | 0 | 0 | 435 | 96 | 0 | 0 | 41760 |
| escuro | nova-ficha-com-selecao | 0 | 0 | 0 | 0 | 435 | 96 | 0 | 0 | 41760 |
| escuro | nova-ficha-com-item | 0 | 0 | 0 | 0 | 414 | 96 | 0 | 0 | 39744 |
| escuro | nova-ficha-item-expandido | 0 | 0 | 0 | 0 | 396 | 108 | 0 | 0 | 42768 |
| escuro | seletor-descanso | 0 | 0 | 0 | 0 | 447 | 124 | 0 | 0 | 55428 |
| escuro | treino-fichas | 0 | 0 | 0 | 0 | 318 | 72 | 0 | 0 | 22896 |
| escuro | treino-exercicios | 0 | 0 | 0 | 0 | 264 | 64 | 0 | 0 | 16896 |
| escuro | detalhe-exercicio | 0 | 0 | 0 | 0 | 483 | 108 | 0 | 0 | 52164 |
| escuro | treino-cardio | 0 | 0 | 0 | 0 | 273 | 48 | 0 | 0 | 13104 |
| escuro | registrar-cardio | 0 | 0 | 0 | 0 | 360 | 80 | 0 | 0 | 28800 |
| escuro | treino-ativo | 0 | 0 | 0 | 0 | 348 | 48 | 0 | 0 | 16704 |
| escuro | treino-exercicio-expandido | 0 | 0 | 0 | 0 | 390 | 84 | 0 | 0 | 32775 |
| escuro | seletor-valores-serie | 0 | 0 | 0 | 0 | 450 | 104 | 0 | 0 | 46815 |
| escuro | timer-descanso | 0 | 0 | 0 | 0 | 435 | 100 | 0 | 0 | 43515 |
| escuro | resumo-treino | 0 | 0 | 0 | 0 | 270 | 28 | 0 | 0 | 7560 |
| escuro | treino-em-andamento | 0 | 0 | 0 | 0 | 336 | 72 | 0 | 0 | 24192 |
| escuro | configuracoes | 0 | 0 | 0 | 0 | 195 | 28 | 0 | 0 | 11928 |
| escuro | config-conta | 0 | 0 | 0 | 0 | 387 | 44 | 0 | 0 | 17028 |
| escuro | config-aparencia | 0 | 0 | 0 | 0 | 390 | 52 | 0 | 0 | 20280 |
| escuro | config-backup | 0 | 0 | 0 | 0 | 390 | 52 | 0 | 0 | 20280 |
| escuro | config-atividade | 0 | 0 | 0 | 0 | 363 | 64 | 0 | 0 | 23232 |
| escuro | config-aparelho | 0 | 0 | 0 | 0 | 402 | 44 | 0 | 0 | 17688 |
| escuro | config-instalar | 0 | 0 | 0 | 0 | 432 | 52 | 0 | 0 | 22464 |
| escuro | config-sobre | 0 | 0 | 0 | 0 | 432 | 52 | 0 | 0 | 22464 |
| escuro | privacidade | 0 | 0 | 0 | 0 | 282 | 36 | 0 | 0 | 10152 |
| escuro | medidas-preenchida | 0 | 0 | 0 | 0 | 282 | 44 | 0 | 0 | 12408 |
| escuro | evolucao-preenchida | 0 | 0 | 0 | 0 | 273 | 48 | 0 | 0 | 13104 |
| claro | hoje | 0 | 0 | 0 | 0 | 255 | 36 | 0 | 0 | 9180 |
| claro | comida | 0 | 0 | 0 | 0 | 207 | 28 | 0 | 0 | 5796 |
| claro | medidas-vazia | 0 | 0 | 0 | 0 | 183 | 28 | 0 | 0 | 5964 |
| claro | registrar-medidas | 0 | 0 | 0 | 0 | 369 | 76 | 0 | 0 | 28044 |
| claro | medida-peso-rolar | 0 | 0 | 0 | 0 | 516 | 148 | 0 | 0 | 76368 |
| claro | medida-peso-digitar | 0 | 0 | 0 | 0 | 432 | 100 | 0 | 0 | 43200 |
| claro | seletor-data | 0 | 0 | 0 | 0 | 492 | 140 | 0 | 0 | 68880 |
| claro | evolucao-vazia | 0 | 0 | 0 | 0 | 183 | 28 | 0 | 0 | 6048 |
| claro | treino-fichas-vazia | 0 | 0 | 0 | 0 | 234 | 48 | 0 | 0 | 11232 |
| claro | nova-ficha-sem-selecao | 0 | 0 | 0 | 0 | 423 | 96 | 0 | 0 | 40608 |
| claro | nova-ficha-com-selecao | 0 | 0 | 0 | 0 | 423 | 96 | 0 | 0 | 40608 |
| claro | nova-ficha-com-item | 0 | 0 | 0 | 0 | 402 | 96 | 0 | 0 | 38592 |
| claro | nova-ficha-item-expandido | 0 | 0 | 0 | 0 | 384 | 108 | 0 | 0 | 41472 |
| claro | seletor-descanso | 0 | 0 | 0 | 0 | 435 | 124 | 0 | 0 | 53940 |
| claro | treino-fichas | 0 | 0 | 0 | 0 | 306 | 72 | 0 | 0 | 22032 |
| claro | treino-exercicios | 0 | 0 | 0 | 0 | 243 | 64 | 0 | 0 | 15552 |
| claro | detalhe-exercicio | 0 | 0 | 0 | 0 | 465 | 100 | 0 | 0 | 46500 |
| claro | treino-cardio | 0 | 0 | 0 | 0 | 258 | 48 | 0 | 0 | 12384 |
| claro | registrar-cardio | 0 | 0 | 0 | 0 | 345 | 80 | 0 | 0 | 27600 |
| claro | treino-ativo | 0 | 0 | 0 | 0 | 336 | 48 | 0 | 0 | 16128 |
| claro | treino-exercicio-expandido | 0 | 0 | 0 | 0 | 378 | 84 | 0 | 0 | 31752 |
| claro | seletor-valores-serie | 0 | 0 | 0 | 0 | 438 | 104 | 0 | 0 | 45552 |
| claro | timer-descanso | 0 | 0 | 0 | 0 | 423 | 100 | 0 | 0 | 42300 |
| claro | resumo-treino | 0 | 0 | 0 | 0 | 258 | 28 | 0 | 0 | 7224 |
| claro | treino-em-andamento | 0 | 0 | 0 | 0 | 324 | 72 | 0 | 0 | 23328 |
| claro | configuracoes | 0 | 0 | 0 | 0 | 183 | 28 | 0 | 0 | 11592 |
| claro | config-conta | 0 | 0 | 0 | 0 | 369 | 44 | 0 | 0 | 16236 |
| claro | config-aparencia | 0 | 0 | 0 | 0 | 378 | 52 | 0 | 0 | 19656 |
| claro | config-backup | 0 | 0 | 0 | 0 | 375 | 52 | 0 | 0 | 19500 |
| claro | config-atividade | 0 | 0 | 0 | 0 | 330 | 64 | 0 | 0 | 21120 |
| claro | config-aparelho | 0 | 0 | 0 | 0 | 378 | 44 | 0 | 0 | 16632 |
| claro | config-instalar | 0 | 0 | 0 | 0 | 411 | 48 | 0 | 0 | 19728 |
| claro | config-sobre | 0 | 0 | 0 | 0 | 411 | 48 | 0 | 0 | 19728 |
| claro | privacidade | 0 | 0 | 0 | 0 | 270 | 36 | 0 | 0 | 9720 |
| claro | medidas-preenchida | 0 | 0 | 0 | 0 | 264 | 44 | 0 | 0 | 11616 |
| claro | evolucao-preenchida | 0 | 0 | 0 | 0 | 261 | 48 | 0 | 0 | 12528 |

### Referência da Fase 0: limite histórico e reconstrução

A Fase 0 guardou 72 PNG e uma seleção de estilos, mas **não** uma matriz completa de propriedades/estados forçados. A matriz completa existente é a de `revisao/lote-2.1/antes/`. Não inventei uma matriz histórica nem substituí nenhum arquivo de baseline.

Para complementar a comparação, reconstruí o snapshot Git f732e69 num diretório temporário, com as dependências atuais idênticas às do controle. Omitir **somente** `revisao/baseline/capturar.cjs` desse espelho reproduziu `index-BRK3Lot8.css`, **198590 bytes**, os mesmos nome/tamanho registrados em `baseline/validacao.json`. Esse script foi criado depois do build original; a palavra `static` em `static now()` acrescenta o utilitário de 24 bytes quando passa a integrar a descoberta automática. Com o script presente, o snapshot compilou 198614 bytes. Nenhum arquivo foi omitido da cópia real.

Não há bytes/hash histórico do bundle completo versionado para comparação literal com 2026-10-25; nome/tamanho são os metadados históricos disponíveis. A reconstrução está identificada como tal, não como observação recuperada do passado.

Essa reconstrução recebeu outro percurso completo, servidor novo em 127.0.0.1:5200: **72 PNG iguais aos originais e aos de antes/, 4.936 estados; todos os grupos a/b/c zerados contra antes/**. A comparação direta posterior entre os snapshots completos do HEAD e os reconstruídos repetiu as mesmas adições do grupo (c). Dados: [comparacao-head-vs-fase0-reconstruida.json](comparacao-head-vs-fase0-reconstruida.json).

## 3. Bissecção — arquivos de revisão, lote e histórico

Cada braço foi extraído de um arquivo Git para uma pasta temporária nova. Nenhum src/ foi editado, nem mesmo nos espelhos. Exclusões foram de arquivos de evidências; dependências compartilhadas por junction, sem reinstalação. O espelho completo do HEAD produziu exatamente o mesmo SHA-256 do projeto real, validando o método. Os hashes agregados de src/ dos quatro braços principais são iguais.


| Braço | Isolamento | Bytes CSS | Nomes emitidos | Três variáveis investigadas | SHA-256 |
| --- | --- | --- | --- | --- | --- |
| espelho-head | Validar réplica contra build real do HEAD | 201067 | 74 | --ease-in-out, --ease-out, --tw-outline-style | a2e67cec7c532920e6a02be9a188a6440cc0a631f2ee7d37b876210687d738e3 |
| sem-revisao | Grupo i: toda a árvore de evidências/scripts/protótipos de revisao fora do build | 196188 | 42 | (nenhuma) | 62d3a5b75f27a5ca44bd72869832138165d1bd99b9c39a12d9876f725d13e8e7 |
| sem-lote-2.1 | Grupo ii: somente os arquivos novos do lote 2.1 fora do build | 200693 | 74 | --ease-in-out, --ease-out, --tw-outline-style | 5ca42bb24b0cb1a287b07a0e3d5f8f9137d962019be0a37d80074b43d6c98c91 |
| espelho-fase0 | Grupo iii: snapshot Fase 0 com as mesmas dependências instaladas | 198614 | 61 | (nenhuma) | 761c693d16d63844075893a9ebd3a41fe97863979278e1bd287bb7efaebf1225 |
| sem seis origens de classes | Retirada parcial; ainda ficam referências --ease-* em relatórios | 200435 | 72 | --ease-in-out, --ease-out | d4779044b642a0731fd452233202a37771a1672a5f1edc1917e7c7416f1ecf98 |
| sem oito origens | Retirada completa dos oito arquivos causadores, só no espelho | 198670 | 61 | (nenhuma) | dad8c8cc04ab0283118851254d5916daf128bb16ed1c03db4fd9344d7a1f0eed |

**Leituras:**

1. Grupo (i): tirar toda revisao/ elimina as três, mas também reduz nomes emitidos de 61 da Fase 0 para 42. Portanto ignorar/mover indiscriminadamente toda a pasta pode remover estilos/variáveis que já faziam parte do baseline; não é a proposta mínima.
2. Grupo (ii): tirar apenas revisao/lote-2.1/ não resolve. Os arquivos da Fase 1 já bastam para emitir as extras.
3. Grupo (iii): src/, package.json, package-lock.json e vite.config.ts não mudaram entre Fase 0 e HEAD. Voltar ao snapshot de evidências da Fase 0 elimina as extras, usando a mesma instalação atual de pacotes. Isso isola a contribuição dos artefatos, sem atribuir a causa a uma versão presumida.
4. Tirar as oito origens restaura exatamente o **conjunto de 61 nomes emitidos da Fase 0**, sem nome a mais ou a menos. Não se afirma que o CSS inteiro fica idêntico: sobram utilitários de outros artefatos, e nenhum movimento foi aplicado no projeto.

### Prova individual de causalidade

Partindo do espelho sem as oito origens, cada arquivo foi recolocado sozinho; extração e compilação do mesmo Tailwind reproduziram a coluna abaixo. Além disso, cada candidato foi compilado sozinho, sem código do app. Não se depende só de encontrar palavras com grep.

| Arquivo recolocado isoladamente | Candidatos relevantes | Variáveis reproduzidas |
| --- | --- | --- |
| revisao/lote-2.1/depois/escuro-hoje-diferencas.json | --ease-in-out, --ease-out | --ease-in-out, --ease-out |
| revisao/INVENTARIO-VISUAL.json | ease-in-out, ease-out, outline | --ease-in-out, --ease-out, --tw-outline-style |
| revisao/gerar-auditoria-visual.cjs | outline | --tw-outline-style |
| revisao/lote-2.1/mapeamento-bordas.json | outline | --tw-outline-style |
| revisao/analise-runtime/resultados.json | outline | --tw-outline-style |
| revisao/AUDITORIA-VISUAL.md | ease-in-out, ease-out, outline | --ease-in-out, --ease-out, --tw-outline-style |
| revisao/BUGS-PRESERVADOS.md | outline | --tw-outline-style |
| revisao/lote-2.1/RELATORIO.md | --ease-in-out, --ease-out | --ease-in-out, --ease-out |

| Candidato mínimo | Variável emitida |
| --- | --- |
| ease-in-out | --ease-in-out |
| ease-out | --ease-out |
| --ease-in-out | --ease-in-out |
| --ease-out | --ease-out |
| outline | --tw-outline-style |

O fluxo local está em `node_modules/@tailwindcss/vite/dist/index.mjs:1`: scanner com base no config.root e padrão **/*, seguido de compiler.build(candidates). Em `node_modules/tailwindcss/dist/lib.js:38`, entradas que começam por dois hífens passam por theme.markUsedVariable. Assim, uma chave JSON ou menção Markdown como `--ease-out` também faz o tema emitir a variável; não precisa haver classe ease-out no JSX.

`outline` cria suporte ao utilitário e a propriedade registrada `--tw-outline-style`, com valor inicial solid. As demais são definidas em `node_modules/tailwindcss/theme.css:435–436`. Os arquivos de prova mínima estão no pacote de evidências.

O CSS do HEAD contém 13 nomes emitidos a mais que a reconstrução da Fase 0. Nas telas/estados computados, somente três têm valor novo observável; os demais são suporte de easing/backdrop sem valor computado adicional nessas observações. Lista de todos os 13:

```text
--ease-in-out
--ease-out
--tw-backdrop-blur
--tw-backdrop-brightness
--tw-backdrop-contrast
--tw-backdrop-grayscale
--tw-backdrop-hue-rotate
--tw-backdrop-invert
--tw-backdrop-opacity
--tw-backdrop-saturate
--tw-backdrop-sepia
--tw-ease
--tw-outline-style
```

### Dependências e hashes

Foram conferidos **512 pacotes instalados**, sem divergência de versão em relação ao lockfile atual. package.json, package-lock.json e vite.config.ts têm os mesmos bytes Git em Fase 0 e HEAD. A diferença entre o hash Git/LF e o hash físico/CRLF do lockfile é apenas representação de fim de linha; o hash físico é igual no projeto e nos espelhos.

| Arquivo | SHA-256 Git Fase 0 | SHA-256 Git HEAD | Iguais |
| --- | --- | --- | --- |
| package.json | a1498096cf1f9fd12c24286bdb82d955075e603fd5470c5596b1c65ea14c2e09 | a1498096cf1f9fd12c24286bdb82d955075e603fd5470c5596b1c65ea14c2e09 | true |
| package-lock.json | 88a83d2c220296c014e58e6ea3991bb9cb5a6c58f663035b5a501a76a42c953b | 88a83d2c220296c014e58e6ea3991bb9cb5a6c58f663035b5a501a76a42c953b | true |
| vite.config.ts | 7cd34431e61a70990fb9a55f6c821fbe9fb595b4372d762b625bc34716aacb62 | 7cd34431e61a70990fb9a55f6c821fbe9fb595b4372d762b625bc34716aacb62 | true |

| Pacote crítico | Versão instalada | SHA-256 agregado de fontes/binding atuais |
| --- | --- | --- |
| tailwindcss | 4.3.3 | 6a3c9fabfb93a3b0a8b1cf986a37657eb6399d33095634e8163d99c3c6ea46e7 |
| @tailwindcss/vite | 4.3.3 | 2cbfef5c94a16d50e677eaa15539aedd5135875565f51884317ecd81749ef0a9 |
| @tailwindcss/node | 4.3.3 | 448b46ea6c1edbd3b2c14474846cb6b42d555a8ba3341b3e19bcefdc2dd9ee17 |
| @tailwindcss/oxide | 4.3.3 | f9ee67309f0c3ab23ea2792ef827fa57372f12a31dd7120a2e70edd3206ab8ee |
| @tailwindcss/oxide-win32-x64-msvc | 4.3.3 | b992524c9b4af962af7344ee6a06aa8673e0b659be55726c3450f3946b87deb0 |
| vite | 8.3.5 | 08362fa57ffbb5ca0cd617f2cc4c36236465fc7ac93576bcd6914140f458841f |
| postcss | 8.5.31 | 13440a33f35af286d440a875081fcca62953d3ace777fc9b6b176f1de8352064 |
| lightningcss | 1.33.0 | 7c5b7c60cbc04e4c28d16112ec439bee4f3bd635fa4c560d7642f091f72003e9 |
| lightningcss-win32-x64-msvc | 1.33.0 | 857d72ea5950440b2000a9b120b5f804c5c36932cb179e709e9679e6e83b14d6 |
| rolldown | 1.2.15 | ac3d6fa3535f0f2c762670a0f8ac4e63e3db7efc9a0e9fd6915d4b791c3a93d0 |
| @rolldown/binding-win32-x64-msvc | 1.2.15 | e75f8d0c3cc9a8234f1c5d367c48b07737c3640fc5bb7ca8d32477fe8870acf2 |
| typescript | 6.0.3 | 17fbd5434b60c0e4abf43680ab90895206962745292f9612dd112da1c1bf0ca5 |
| @vitejs/plugin-react | 6.1.2 | 26861943a5e9a2d1a4dabce91f9cc42976693ce80ee94c233fbcc8cc6662405a |

Hashes completos por arquivo estão em dependencias.json. Caches .vite/.tmp e node_modules aninhados não integram o hash agregado de cada pacote crítico. O executável Node atual é v24.18.0, SHA-256 9a4eb5f1c29c6a2e93852ead46b999e284a6a5ca8bab4d4e241d587d025a52de. A Fase 0 **não registrou hashes históricos de node_modules nem do Node**; não é possível certificar retrospectivamente esses bytes. Não houve npm install/update nesta etapa e todos os braços usaram a mesma instalação, eliminando essa variável dos testes causais.

### O que está provado e o que continua hipótese

**Provado:** oito artefatos fora de src/ são fontes efetivas de candidatos que emitem as três variáveis; retirar/recolocar e reproduções mínimas confirmaram o encadeamento. O HEAD frio já as emite sem o Lote 2.1. A tentativa não era necessária para produzi-las.

**Não reconstituído historicamente:** o evento exato de HMR/cache que fez a referência antes/ ficar sem elas e a recompilação posterior incluí-las. O plugin mantém candidatos em memória; um processo aquecido/recompilação tardia é compatível com os dados, mas não há logs históricos que provem esse momento. Essa limitação não invalida a prova controlada de quais entradas geram a emissão.

## 4. Fontes automáticas e palavras encontradas

O scanner nativo instalado listou **507 arquivos**, sendo **338 fora de src/**. Base automática: raiz do projeto, padrão **/*; compiler.root=null e sem fontes adicionais declaradas no CSS. Inventário completo: [head-fontes.json](head-fontes.json).

Apenas achar texto ou chamar getCandidatesWithPositions em CSS não prova contribuição automática. Há folhas CSS listadas com as palavras que não geram esses candidatos no scan automático; isso foi separado de fontes efetivas. As oito efetivas são todas artefatos de revisão, não componentes.


| Fonte efetiva | Candidatos automáticos | Linhas de exemplo (todas em origens-completas.json) |
| --- | --- | --- |
| revisao/lote-2.1/depois/escuro-hoje-diferencas.json | --ease-in-out, --ease-out | 540, 1586, 2632, 3678, 4724, 541, 1587, 2633, 3679, 4725 |
| revisao/INVENTARIO-VISUAL.json | ease-in-out, ease-out, outline | 703, 713, 723, 783, 793, 803, 813, 823, 833, 843, 853, 863 |
| revisao/gerar-auditoria-visual.cjs | outline | 243 |
| revisao/lote-2.1/mapeamento-bordas.json | outline | 189, 244, 277, 508, 519, 585, 706, 717, 904, 970, 1256, 1707 |
| revisao/analise-runtime/resultados.json | outline | 15, 94, 181, 244, 315, 402, 473, 552, 649, 760, 863, 982 |
| revisao/AUDITORIA-VISUAL.md | ease-in-out, ease-out, outline | 344, 1225, 1234, 1285, 1289, 1418, 1566, 1609, 1634, 1691, 1709, 1720 |
| revisao/BUGS-PRESERVADOS.md | outline | 44, 78, 81, 82, 86 |
| revisao/lote-2.1/RELATORIO.md | --ease-in-out, --ease-out | 10 |

### Arquivos fora de src/ que contêm as palavras pesquisadas

As contagens são literais; incluem prefixos de variáveis, trechos de CSS e menções em documentação. A coluna de candidatos é a contribuição efetiva confirmada, não uma inferência por substring.

| Arquivo | ease-in-out | ease-out | outline | Candidatos efetivos relevantes |
| --- | --- | --- | --- | --- |
| revisao/lote-2.1/depois/escuro-hoje-diferencas.json | 5 | 5 | 45 | --ease-in-out, --ease-out |
| revisao/INVENTARIO-VISUAL.json | 1 | 38 | 36 | ease-in-out, ease-out, outline |
| revisao/gerar-auditoria-visual.cjs | 0 | 0 | 1 | outline |
| revisao/prototipo-repaginacao/estilos.css | 0 | 11 | 23 | (nenhum destes) |
| revisao/lote-2.1/mapeamento-bordas.json | 0 | 0 | 13 | outline |
| revisao/auditar-runtime.cjs | 0 | 0 | 2 | (nenhum destes) |
| revisao/prototipo-refino-visual/estilos/index.css | 1 | 0 | 26 | (nenhum destes) |
| revisao/analise-runtime/resultados.json | 0 | 0 | 50 | outline |
| revisao/prototipo-refino-visual/estilos/controles.css | 0 | 12 | 4 | (nenhum destes) |
| revisao/AUDITORIA-VISUAL.md | 1 | 12 | 30 | ease-in-out, ease-out, outline |
| revisao/BUGS-PRESERVADOS.md | 0 | 0 | 5 | outline |
| revisao/prototipo-repaginacao/correcoes-codex.css | 0 | 0 | 9 | (nenhum destes) |
| revisao/prototipo-refino-visual/estilos/refino.css | 0 | 7 | 13 | (nenhum destes) |
| revisao/conferir-foco-alca.cjs | 0 | 0 | 1 | (nenhum destes) |
| revisao/gerar-paleta-clara.cjs | 0 | 0 | 2 | (nenhum destes) |
| revisao/lote-2.1/relatar-reprovacao.cjs | 1 | 1 | 1 | (nenhum destes) |
| revisao/lote-2.1/RELATORIO.md | 1 | 1 | 1 | --ease-in-out, --ease-out |

### Lista completa das fontes automáticas fora de src/

```text
.github/dependabot.yml
.github/workflows/validacao.yml
AGENTS.md
CHANGELOG.md
CONTINUAR-AMANHA.md
COPIA-ISOLADA.md
ENTREGA.md
GEMINI.md
ORIGEM-COPIA.json
PADROES-INTERFACE.md
README.md
ambiente-isolado/README.md
eslint.config.js
index.html
package.json
revisao/APP-01-ISOLAMENTO.md
revisao/APP-03-ELIMINACAO.md
revisao/APP-04-BACKUP.md
revisao/AUDITORIA-VISUAL.md
revisao/BUGS-PRESERVADOS.md
revisao/CHECKLIST-PRODUCAO.md
revisao/CHECKUP-VISUAL.md
revisao/CODEX-A03.md
revisao/CODEX-A05.md
revisao/CODEX-A07.md
revisao/CODEX-A09.md
revisao/CODEX-A10.md
revisao/CODEX-CATALOGO-ESTAVEL.md
revisao/CODEX-DETALHES-CARDIO.md
revisao/CODEX-DUPLICATAS.md
revisao/CODEX-ISOLAMENTO-ENTRADA.md
revisao/CODEX-PROTOTIPO-CARDS.md
revisao/CODEX-SELETORES-CARDIO.md
revisao/CODEX.md
revisao/COMPATIBILIDADE-WIFI.md
revisao/CONSOLIDADO.md
revisao/CONTRASTE-CLARO.md
revisao/CORRECOES.md
revisao/DESLIZAR-ABAS.md
revisao/DEVOLUTIVA-CODEX-REPAGINACAO.md
revisao/DIAGNOSTICO-ACESSO-IPHONE.md
revisao/FLUIDEZ-E-DESEMPENHO.md
revisao/GEMINI-A05.md
revisao/GEMINI-A07.md
revisao/GEMINI-PROTOTIPO-CARDS.md
revisao/GEMINI-REFINO-VISUAL.md
revisao/GEMINI-REPAGINACAO.md
revisao/GEMINI-SELETORES-CARDIO.md
revisao/GEMINI.md
revisao/INVENTARIO-PARIDADE.json
revisao/INVENTARIO-VISUAL.json
revisao/LOTE-4-HEADERS-CI.md
revisao/NOVO-VISUAL-REACT.md
revisao/PARIDADE-APP-PROTOTIPO.md
revisao/PLANO.md
revisao/REFERENCIAS-EXERCICIOS-OCR.json
revisao/RUNBOOK-PRODUCAO.md
revisao/TAREFA-GEMINI-A05.md
revisao/TAREFA-GEMINI-PROTOTIPO-CARDS.md
revisao/TAREFA-GEMINI-SELETORES-CARDIO.md
revisao/TRANSICOES-SUAVES.md
revisao/analise-runtime/README.md
revisao/analise-runtime/alvos-toque.json
revisao/analise-runtime/contrastes-bordas.json
revisao/analise-runtime/contrastes-texto.json
revisao/analise-runtime/integridade.json
revisao/analise-runtime/percurso/capturas.json
revisao/analise-runtime/percurso/claro-cobertura-css.json
revisao/analise-runtime/percurso/claro-comida.json
revisao/analise-runtime/percurso/claro-config-aparelho.json
revisao/analise-runtime/percurso/claro-config-aparencia.json
revisao/analise-runtime/percurso/claro-config-atividade.json
revisao/analise-runtime/percurso/claro-config-backup.json
revisao/analise-runtime/percurso/claro-config-conta.json
revisao/analise-runtime/percurso/claro-config-instalar.json
revisao/analise-runtime/percurso/claro-config-sobre.json
revisao/analise-runtime/percurso/claro-configuracoes.json
revisao/analise-runtime/percurso/claro-detalhe-exercicio.json
revisao/analise-runtime/percurso/claro-evolucao-preenchida.json
revisao/analise-runtime/percurso/claro-evolucao-vazia.json
revisao/analise-runtime/percurso/claro-hoje.json
revisao/analise-runtime/percurso/claro-medida-peso-digitar.json
revisao/analise-runtime/percurso/claro-medida-peso-rolar.json
revisao/analise-runtime/percurso/claro-medidas-preenchida.json
revisao/analise-runtime/percurso/claro-medidas-vazia.json
revisao/analise-runtime/percurso/claro-nova-ficha-com-item.json
revisao/analise-runtime/percurso/claro-nova-ficha-com-selecao.json
revisao/analise-runtime/percurso/claro-nova-ficha-item-expandido.json
revisao/analise-runtime/percurso/claro-nova-ficha-sem-selecao.json
revisao/analise-runtime/percurso/claro-privacidade.json
revisao/analise-runtime/percurso/claro-registrar-cardio.json
revisao/analise-runtime/percurso/claro-registrar-medidas.json
revisao/analise-runtime/percurso/claro-resumo-treino.json
revisao/analise-runtime/percurso/claro-seletor-data.json
revisao/analise-runtime/percurso/claro-seletor-descanso.json
revisao/analise-runtime/percurso/claro-seletor-valores-serie.json
revisao/analise-runtime/percurso/claro-timer-descanso.json
revisao/analise-runtime/percurso/claro-treino-ativo.json
revisao/analise-runtime/percurso/claro-treino-cardio.json
revisao/analise-runtime/percurso/claro-treino-em-andamento.json
revisao/analise-runtime/percurso/claro-treino-exercicio-expandido.json
revisao/analise-runtime/percurso/claro-treino-exercicios.json
revisao/analise-runtime/percurso/claro-treino-fichas-vazia.json
revisao/analise-runtime/percurso/claro-treino-fichas.json
revisao/analise-runtime/percurso/escuro-cobertura-css.json
revisao/analise-runtime/percurso/escuro-comida.json
revisao/analise-runtime/percurso/escuro-config-aparelho.json
revisao/analise-runtime/percurso/escuro-config-aparencia.json
revisao/analise-runtime/percurso/escuro-config-atividade.json
revisao/analise-runtime/percurso/escuro-config-backup.json
revisao/analise-runtime/percurso/escuro-config-conta.json
revisao/analise-runtime/percurso/escuro-config-instalar.json
revisao/analise-runtime/percurso/escuro-config-sobre.json
revisao/analise-runtime/percurso/escuro-configuracoes.json
revisao/analise-runtime/percurso/escuro-detalhe-exercicio.json
revisao/analise-runtime/percurso/escuro-evolucao-preenchida.json
revisao/analise-runtime/percurso/escuro-evolucao-vazia.json
revisao/analise-runtime/percurso/escuro-hoje.json
revisao/analise-runtime/percurso/escuro-medida-peso-digitar.json
revisao/analise-runtime/percurso/escuro-medida-peso-rolar.json
revisao/analise-runtime/percurso/escuro-medidas-preenchida.json
revisao/analise-runtime/percurso/escuro-medidas-vazia.json
revisao/analise-runtime/percurso/escuro-nova-ficha-com-item.json
revisao/analise-runtime/percurso/escuro-nova-ficha-com-selecao.json
revisao/analise-runtime/percurso/escuro-nova-ficha-item-expandido.json
revisao/analise-runtime/percurso/escuro-nova-ficha-sem-selecao.json
revisao/analise-runtime/percurso/escuro-privacidade.json
revisao/analise-runtime/percurso/escuro-registrar-cardio.json
revisao/analise-runtime/percurso/escuro-registrar-medidas.json
revisao/analise-runtime/percurso/escuro-resumo-treino.json
revisao/analise-runtime/percurso/escuro-seletor-data.json
revisao/analise-runtime/percurso/escuro-seletor-descanso.json
revisao/analise-runtime/percurso/escuro-seletor-valores-serie.json
revisao/analise-runtime/percurso/escuro-timer-descanso.json
revisao/analise-runtime/percurso/escuro-treino-ativo.json
revisao/analise-runtime/percurso/escuro-treino-cardio.json
revisao/analise-runtime/percurso/escuro-treino-em-andamento.json
revisao/analise-runtime/percurso/escuro-treino-exercicio-expandido.json
revisao/analise-runtime/percurso/escuro-treino-exercicios.json
revisao/analise-runtime/percurso/escuro-treino-fichas-vazia.json
revisao/analise-runtime/percurso/escuro-treino-fichas.json
revisao/analise-runtime/resultados.json
revisao/auditar-contraste.cjs
revisao/auditar-percurso.cjs
revisao/auditar-runtime.cjs
revisao/auditar-visual.cjs
revisao/auditoria.test.ts
revisao/baseline/README.md
revisao/baseline/capturar.cjs
revisao/baseline/capturas.json
revisao/baseline/claro-cobertura-css.json
revisao/baseline/claro-comida.json
revisao/baseline/claro-config-aparelho.json
revisao/baseline/claro-config-aparencia.json
revisao/baseline/claro-config-atividade.json
revisao/baseline/claro-config-backup.json
revisao/baseline/claro-config-conta.json
revisao/baseline/claro-config-instalar.json
revisao/baseline/claro-config-sobre.json
revisao/baseline/claro-configuracoes.json
revisao/baseline/claro-detalhe-exercicio.json
revisao/baseline/claro-evolucao-preenchida.json
revisao/baseline/claro-evolucao-vazia.json
revisao/baseline/claro-hoje.json
revisao/baseline/claro-medida-peso-digitar.json
revisao/baseline/claro-medida-peso-rolar.json
revisao/baseline/claro-medidas-preenchida.json
revisao/baseline/claro-medidas-vazia.json
revisao/baseline/claro-nova-ficha-com-item.json
revisao/baseline/claro-nova-ficha-com-selecao.json
revisao/baseline/claro-nova-ficha-item-expandido.json
revisao/baseline/claro-nova-ficha-sem-selecao.json
revisao/baseline/claro-privacidade.json
revisao/baseline/claro-registrar-cardio.json
revisao/baseline/claro-registrar-medidas.json
revisao/baseline/claro-resumo-treino.json
revisao/baseline/claro-seletor-data.json
revisao/baseline/claro-seletor-descanso.json
revisao/baseline/claro-seletor-valores-serie.json
revisao/baseline/claro-timer-descanso.json
revisao/baseline/claro-treino-ativo.json
revisao/baseline/claro-treino-cardio.json
revisao/baseline/claro-treino-em-andamento.json
revisao/baseline/claro-treino-exercicio-expandido.json
revisao/baseline/claro-treino-exercicios.json
revisao/baseline/claro-treino-fichas-vazia.json
revisao/baseline/claro-treino-fichas.json
revisao/baseline/css-metricas.json
revisao/baseline/escuro-cobertura-css.json
revisao/baseline/escuro-comida.json
revisao/baseline/escuro-config-aparelho.json
revisao/baseline/escuro-config-aparencia.json
revisao/baseline/escuro-config-atividade.json
revisao/baseline/escuro-config-backup.json
revisao/baseline/escuro-config-conta.json
revisao/baseline/escuro-config-instalar.json
revisao/baseline/escuro-config-sobre.json
revisao/baseline/escuro-configuracoes.json
revisao/baseline/escuro-detalhe-exercicio.json
revisao/baseline/escuro-evolucao-preenchida.json
revisao/baseline/escuro-evolucao-vazia.json
revisao/baseline/escuro-hoje.json
revisao/baseline/escuro-medida-peso-digitar.json
revisao/baseline/escuro-medida-peso-rolar.json
revisao/baseline/escuro-medidas-preenchida.json
revisao/baseline/escuro-medidas-vazia.json
revisao/baseline/escuro-nova-ficha-com-item.json
revisao/baseline/escuro-nova-ficha-com-selecao.json
revisao/baseline/escuro-nova-ficha-item-expandido.json
revisao/baseline/escuro-nova-ficha-sem-selecao.json
revisao/baseline/escuro-privacidade.json
revisao/baseline/escuro-registrar-cardio.json
revisao/baseline/escuro-registrar-medidas.json
revisao/baseline/escuro-resumo-treino.json
revisao/baseline/escuro-seletor-data.json
revisao/baseline/escuro-seletor-descanso.json
revisao/baseline/escuro-seletor-valores-serie.json
revisao/baseline/escuro-timer-descanso.json
revisao/baseline/escuro-treino-ativo.json
revisao/baseline/escuro-treino-cardio.json
revisao/baseline/escuro-treino-em-andamento.json
revisao/baseline/escuro-treino-exercicio-expandido.json
revisao/baseline/escuro-treino-exercicios.json
revisao/baseline/escuro-treino-fichas-vazia.json
revisao/baseline/escuro-treino-fichas.json
revisao/baseline/fontes-copia-sha256.json
revisao/baseline/fontes-original-sha256.json
revisao/baseline/index.html
revisao/baseline/validacao.json
revisao/comparar-resumo-treino.cjs
revisao/conferir-catalogo-completo.cjs
revisao/conferir-configuracoes.cjs
revisao/conferir-descanso.cjs
revisao/conferir-deslize-abas.cjs
revisao/conferir-espacamento.cjs
revisao/conferir-espacos-telas.cjs
revisao/conferir-fluidez.cjs
revisao/conferir-foco-alca.cjs
revisao/conferir-memoria-descanso.cjs
revisao/conferir-offline-visual.cjs
revisao/conferir-padroes-visuais.cjs
revisao/conferir-previa-card.cjs
revisao/conferir-reserva-treino.cjs
revisao/conferir-selecao-proximas.cjs
revisao/conferir-transicao-suave.cjs
revisao/conferir-wifi.cjs
revisao/contraste-claro.json
revisao/diagnosticar-wifi.cjs
revisao/firewall-wifi-status.json
revisao/fluidez-antes.json
revisao/fluidez-depois.json
revisao/gemini-entrada.test.tsx
revisao/gerar-auditoria-visual.cjs
revisao/gerar-ids-wifi.cjs
revisao/gerar-paleta-clara.cjs
revisao/homologar-novo-visual.cjs
revisao/lote-2.1/README.md
revisao/lote-2.1/RELATORIO.md
revisao/lote-2.1/antes/capturas.json
revisao/lote-2.1/antes/claro-cobertura-css.json
revisao/lote-2.1/antes/escuro-cobertura-css.json
revisao/lote-2.1/antes/resultado.json
revisao/lote-2.1/aplicacao.json
revisao/lote-2.1/aplicar.cjs
revisao/lote-2.1/build.txt
revisao/lote-2.1/depois/capturas.json
revisao/lote-2.1/depois/escuro-hoje-diferencas.json
revisao/lote-2.1/depois/novos-tokens-computados.json
revisao/lote-2.1/depois/resultado.json
revisao/lote-2.1/gate.cjs
revisao/lote-2.1/mapeamento-bordas.json
revisao/lote-2.1/preparar-tokens.cjs
revisao/lote-2.1/relatar-reprovacao.cjs
revisao/lote-2.1/resumo-final.json
revisao/lote-2.1/reversao-verificada.json
revisao/lote-2.1/testes.txt
revisao/lote-2.1/tokens-propostos.css
revisao/lote-2.1/tokens-propostos.json
revisao/lote-2.1/validar-estatico.cjs
revisao/medir-fluidez.cjs
revisao/pktmon-antes.txt
revisao/pktmon-captura-status.txt
revisao/prototipo-cards/index.html
revisao/prototipo-cards/verificar-prototipo.mjs
revisao/prototipo-refino-visual/app.js
revisao/prototipo-refino-visual/estilos/controles.css
revisao/prototipo-refino-visual/estilos/index.css
revisao/prototipo-refino-visual/estilos/refino.css
revisao/prototipo-refino-visual/index.html
revisao/prototipo-refino-visual/scratch/test_treino_flow.mjs
revisao/prototipo-refino-visual/servidor.mjs
revisao/prototipo-refino-visual/treino-interativo.js
revisao/prototipo-refino-visual/validar-treino.cjs
revisao/prototipo-refino-visual/verificar-refino-visual.mjs
revisao/prototipo-repaginacao/REVISAO-CODEX.md
revisao/prototipo-repaginacao/acabamento-codex.js
revisao/prototipo-repaginacao/agua-codex.js
revisao/prototipo-repaginacao/app.js
revisao/prototipo-repaginacao/backup-demonstracao-codex.js
revisao/prototipo-repaginacao/compartilhamento-codex.js
revisao/prototipo-repaginacao/correcoes-codex.css
revisao/prototipo-repaginacao/correcoes-codex.js
revisao/prototipo-repaginacao/estilos.css
revisao/prototipo-repaginacao/funcionalidades-codex.js
revisao/prototipo-repaginacao/historico-codex.js
revisao/prototipo-repaginacao/index.html
revisao/prototipo-repaginacao/renderer-aprovado-copia.js
revisao/prototipo-repaginacao/renderer-origem.json
revisao/prototipo-repaginacao/servidor.mjs
revisao/prototipo-repaginacao/validar-agua.cjs
revisao/prototipo-repaginacao/validar-codex.cjs
revisao/prototipo-repaginacao/verificar-repaginacao.mjs
revisao/verificar-copia-isolada.cjs
revisao/wifi-captura-pronta.txt
revisao/wifi-iphone.etl
revisao/wifi-iphone.txt
revisao/wifi-wfp-events.xml
revisao/wifi-wfp-filters.xml
revisao/wifi-wfp-status.txt
supabase/CONFIGURAR.md
supabase/config.toml
supabase/confirmar-cadastro.html
supabase/functions/_shared/handlers.ts
supabase/functions/_shared/runtime.ts
supabase/functions/_shared/servicos.ts
supabase/functions/deno.json
supabase/functions/excluir-conta/index.ts
supabase/functions/purgar-removidos/index.ts
supabase/migrations/202610140001_conta_sincronizacao.sql
supabase/migrations/202610210001_eliminacao.sql
supabase/templates/recuperar-senha.html
supabase/verificacao/checagem_seguranca.sql
tsconfig.app.json
tsconfig.edge.json
tsconfig.json
tsconfig.node.json
vercel.json
vite.config.ts
```

## 5. Correção mínima proposta — NÃO APLICADA

**Preferida: retirar da árvore varrida os oito arquivos efetivos listados acima**, mantendo a estrutura relativa num diretório irmão, por exemplo `vida-em-dia-evidencias/revisao/`. Ajustar apenas os caminhos das ferramentas para ler/gravar nesse diretório externo; futuras evidências também devem nascer fora da raiz. Se necessário, deixar no endereço antigo um ponteiro simples sem dados CSS, cujo conjunto de candidatos deve ser conferido.

Mover é tecnicamente possível e foi simulado nos espelhos. Nenhum dos oito arquivos é lógica, teste ou componente do app. **Nenhum causador original foi movido/excluído na cópia real.** O relatório desta etapa também foi produzido fora da árvore para não se tornar outra entrada do compilador.

A proposta é pontual: não mover/ignorar indiscriminadamente toda revisao/, pois isso altera o conjunto antigo de estilos/variáveis. Depois de eventual autorização, repetir o gate antes de aceitar qualquer migração. A simulação demonstra a remoção das três e a igualdade de nomes emitidos, não substitui essa validação pós-correção na cópia.

**Fallback não escolhido:** somente se uma restrição impedir mover e houver autorização específica, declarar exclusões precisas em `src/index.css`, após a linha 1 (a partir da linha 2), usando @source not para os oito caminhos. Não excluir a pasta inteira. Nenhuma diretiva, configuração, allowlist, versão, pipeline ou baseline foi alterado nesta etapa.

## 6. #7c8d76 por grep

Escopo: sete CSS de src/, os mesmos do Apêndice D. Não inclui dist/, propostas descartadas ou palavras em comentários dos relatórios. Comando executado:

```powershell
rg --count-matches -i "#7c8d76" src/index.css src/estilos/controles.css src/estilos/novo-visual.css src/estilos/paleta-clara.css src/estilos/contraste-claro.css src/estilos/superficies.css src/estilos/transicoes.css
```

Saída literal:

```text
src/estilos/contraste-claro.css:2
src/estilos/paleta-clara.css:169
```

| Arquivo | Ocorrências |
| --- | --- |
| src/index.css | 0 |
| src/estilos/controles.css | 0 |
| src/estilos/novo-visual.css | 0 |
| src/estilos/paleta-clara.css | 169 |
| src/estilos/contraste-claro.css | 2 |
| src/estilos/superficies.css | 0 |
| src/estilos/transicoes.css | 0 |

**Total: 171.** Arquivos sem saída do rg têm zero. Nenhuma substituição de borda foi realizada.

## 7. Integridade e estado final

Os hashes dos **169 arquivos de src/ da cópia e 153 do original** permanecem iguais à Fase 0, incluindo renderizadores e testes. Os quatro espelhos principais têm o mesmo hash agregado de src/. O HEAD da execução foi mantido sem alterações de arquivos enquanto se coletavam os controles; resultados, scripts e variantes ficaram em diretório temporário externo. As únicas escritas do build no projeto foram artefatos ignorados/cache padrão das ferramentas.

Nenhum comando de aplicação do Lote 2.1 foi executado. Nenhuma regra/token do app foi alterado; nenhuma correção proposta foi aplicada. Não houve push ou deploy. **Etapa A concluída; parar e aguardar decisão.**
